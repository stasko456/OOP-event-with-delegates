﻿class Program()
{
    public static void GreetUser()
    {
        Console.WriteLine($"Greetings from us, sir!");
    }

    public static void PrintDate()
    {
        Console.WriteLine($"Today's date is:{DateTime.Now}!");
    }

    public delegate void GreetingDelegate();

    public static void Main(string[] argms)
    {
        GreetingDelegate del = GreetUser;
        del = del + PrintDate;

        del();
    }
}
