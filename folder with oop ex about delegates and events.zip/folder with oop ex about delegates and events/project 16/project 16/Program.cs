﻿class Program()
{
    public delegate int MathOperation(int number1, int number2);

    public static void Main()
    {
        MathOperation dele = (number1,number2) => number1 + number2;

        int result = dele(5,5);

        Console.WriteLine($"The result is:{result}!");
    }
}
