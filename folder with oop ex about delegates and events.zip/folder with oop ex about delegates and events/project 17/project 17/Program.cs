﻿class Program()
{
    public delegate string StringOperation(string message);

    public static void Main()
    {
        StringOperation dele = (message ) => message.ToUpper();

        string result = dele("stasko");

        Console.WriteLine($"The result in upper cases is:{result}!");
    }
}
