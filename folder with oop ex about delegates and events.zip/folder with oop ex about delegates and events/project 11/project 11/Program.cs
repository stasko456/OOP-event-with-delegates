﻿class Program()
{
    public static void PrintUserInfo()
    {
        Console.WriteLine($"User's name:Stanislav, age:18!");
    }

    public static void PrintLocation()
    {
        Console.WriteLine($"User's location:Kazanlak, Bulgaria!");
    }

    public delegate void UserInfoDelegate();

    public static void Main(string[] argms)
    {
        UserInfoDelegate del1 = PrintUserInfo;

        del1 = del1 + PrintLocation;

        del1();
    }
}