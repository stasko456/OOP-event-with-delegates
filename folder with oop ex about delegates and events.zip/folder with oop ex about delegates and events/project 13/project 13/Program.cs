﻿class Program()
{
    public delegate int OperationDelegate(int number1, int number2);

    public static int Subtract(int number1, int numer2)
    {
        return number1 - numer2;
    }

    public static int Divide(int number1, int numer2)
    {
        return number1 / numer2;
    }

    public static void ExecuteOperation(OperationDelegate operation, int number1, int number2)
    {
        int result = operation(number1, number2);
        Console.WriteLine($"The result is:{result}!");
    }

    public static void Main(string[] argms)
    {
        OperationDelegate subtractOperation = Subtract;
        Console.WriteLine("Subtract:");
        ExecuteOperation(subtractOperation, 5,2);

        OperationDelegate devidOperation = Divide;
        Console.WriteLine("Devide:");
        ExecuteOperation(devidOperation, 10, 2);
    }
}
