﻿class Program
{
    public delegate void MessageDelegate(string message);

    public static void Main(string[] armgs)
    {
        MessageDelegate del = delegate (string message)
        {
            Console.WriteLine(message);
        };

        del("This is an anonymous method example!");
    }
}