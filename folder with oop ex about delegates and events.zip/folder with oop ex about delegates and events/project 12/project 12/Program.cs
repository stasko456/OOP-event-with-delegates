﻿using System.ComponentModel;

class Program()
{
    public delegate int MathOperation(int number1, int number2);

    public static int Add(int number1, int number2)
    {
        return number1 + number2;
    }

    public static int Multiply(int number1, int number2)
    {
        return (number1 * number2);
    }

    public static void PerformCalculation(MathOperation operation, int number1, int number2)
    {
        int result = operation(number1, number2);
        Console.WriteLine($"The result is:{result}!");
    }

    public static void Main(string[] argms)
    {
        MathOperation addOperation = Add;
        MathOperation multiplicationOperation = Multiply;

        Console.WriteLine($"Add operation:");
        PerformCalculation(addOperation, 1,2);

        Console.WriteLine($"Multiply operation:");
        PerformCalculation(multiplicationOperation, 1, 2);

    }
}   