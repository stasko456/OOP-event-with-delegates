﻿class Program()
{
    public static void DisplayGreeting(string parameter)
    {
        Console.WriteLine($"The message is:{parameter}.");
    }

    public delegate void DisplayMessage(string parameter);

    public static void Main(string[] argms)
    {
        DisplayMessage dele = new DisplayMessage(DisplayGreeting);
        dele("mama");
    }
}