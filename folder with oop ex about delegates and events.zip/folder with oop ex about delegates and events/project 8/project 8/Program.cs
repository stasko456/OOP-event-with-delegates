﻿class Program()
{
    public delegate void SimpleDelegate(int number);

    public static void PrintNumber(int number)
    {
        Console.WriteLine($"The number is:{number}!");
    }

    public static void Main(string[] argms)
    {
        SimpleDelegate dele = new SimpleDelegate(PrintNumber);
        dele(10);
    }
}

