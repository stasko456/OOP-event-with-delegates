﻿class Program()
{
    public delegate void DisplayNumber(int number);

    public static void Main()
    {
        DisplayNumber dele = delegate (int number)
        {
            if (number % 2 == 0)
            {
                Console.WriteLine("Even number"!);
            }
            else if (number % 2 != 0)
            {
                Console.WriteLine("Odd number!");
            }
        };

        dele(5);
    }
}
